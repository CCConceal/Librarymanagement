#include <iostream>
#include <algorithm>
#include "admin.h"
#include "utils.h"
#include"book.h"
#include<vector>
using namespace std;

// =================== Admin Control Panel Functions ===================

void displayAdminControlPanel(vector<Book>& books,
    vector<TransactionReceipt>& receipts,
    const vector<User>& users,
    int& nextBookID,
    int& nextReceiptNumber) {
    int choice;
    do {
        cout << "===== Admin Control Panel =====\n"
            << "1. Add New Book\n"
            << "2. Search Book by ID\n"
            << "3. Edit Book Details\n"
            << "4. Delete Book\n"
            << "5. View All Books\n"
            << "6. Sort Books by ID (Merge Sort)\n"
            << "7. Sort Books by ID (Quick Sort)\n"
            << "8. Sort Books by Title\n"
            << "9. Shuffle Books Order\n" 
            << "10. View Transaction Receipts (Selection Sort)\n"
            << "11. Search Transaction Receipts by User ID\n"
            << "12. Return to Main Control Panel\n" 
            << "Please select an option: ";

        if (!(cin >> choice)) {
            cout << "Invalid input. Please enter a number between 1 and 12.\n\n";
            clearInputBuffer();
            continue;
        }
        clearInputBuffer();

        switch (choice) {
        case 1:
            addBook(books, nextBookID);
            break;
        case 2:
            searchBookByID(books);
            break;
        case 3:
            editBook(books);
            break;
        case 4:
            deleteBook(books);
            break;
        case 5:
            viewAllBooks(books);
            break;
        case 6:
            sortBooksByID(books); // Merge Sort
            break;
        case 7:
            sortBooksByIDQuickSort(books); // Quick Sort
            break;
        case 8:
            sortBooksByTitle(books); // Bubble Sort
            break;
        case 9:
            shuffleBooks(books); // Call the disrupt function
            displayBooks(books); // Show disorganised books
            break;
        case 10:
            selectionSortReceiptsAndView(receipts);
            break;
        case 11:
            searchTransactionReceiptsByUserID_BinarySearch(receipts);
            break;
        case 12:
            cout << "Returning to Main Control Panel...\n\n";
            return;
        default:
            cout << "Invalid option. Please try again.\n\n";
            break;
        }
    } while (choice != 12);
}

// =================== Book Management (Admin) ===================

void addBook(vector<Book>& books, int& nextBookID) {
    Book newBook;
    newBook.ID = findNextAvailableBookID(books);

    while (true) {
        cout << "Enter book title: ";
        getline(cin, newBook.title);
        if (!newBook.title.empty()) break;
        cout << "Book title cannot be empty. Please try again.\n";
    }

    while (true) {
        cout << "Enter author: ";
        getline(cin, newBook.author);
        if (!newBook.author.empty()) break;
        cout << "Author cannot be empty. Please try again.\n";
    }

    while (true) {
        cout << "Enter category: ";
        getline(cin, newBook.category);
        if (!newBook.category.empty()) break;
        cout << "Category cannot be empty. Please try again.\n";
    }

    char availChoice;
    while (true) {
        cout << "Is the book available for borrowing? (y/n): ";
        cin >> availChoice;
        clearInputBuffer();
        if (availChoice == 'y' || availChoice == 'Y' ||
            availChoice == 'n' || availChoice == 'N') {
            newBook.availability = (availChoice == 'y' || availChoice == 'Y');
            break;
        }
        else {
            cout << "Invalid choice. Please enter 'y' or 'n'.\n";
        }
    }

    books.push_back(newBook);
    sort(books.begin(), books.end(), [](const Book& a, const Book& b) {
        return a.ID < b.ID;
        });

    if (newBook.ID >= nextBookID) {
        nextBookID = newBook.ID + 1;
    }

    cout << "Book added successfully!\n\n";
    if (!saveBooksToFile(books, "books.txt")) {
        cerr << "Error: Failed to save books to file after adding a new book.\n";
    }
}

void searchBookByID(const vector<Book>& books) {
    if (books.empty()) {
        cout << "No books in the system.\n\n";
        return;
    }

    cout << "Enter the book ID to search: ";
    int targetID;
    validateIntegerInput(targetID);

    int index = binarySearchBookByID(books, targetID);
    if (index != -1) {
        const Book& foundBook = books[index];
        cout << "Book found:\n";
        cout << "ID: " << foundBook.ID
            << "\nTitle: " << foundBook.title
            << "\nAuthor: " << foundBook.author
            << "\nCategory: " << foundBook.category
            << "\nAvailable: " << (foundBook.availability ? "Yes" : "No") << "\n\n";
    }
    else {
        cout << "Book not found.\n\n";
    }
}

void editBook(vector<Book>& books) {
    if (books.empty()) {
        cout << "No books available to edit.\n\n";
        return;
    }

    cout << "Enter the book ID to edit: ";
    int targetID;
    validateIntegerInput(targetID);

    auto it = find_if(books.begin(), books.end(), [targetID](const Book& bk) {
        return bk.ID == targetID;
        });

    if (it == books.end()) {
        cout << "Book not found.\n\n";
        return;
    }

    cout << "Editing Book (ID: " << it->ID << ")\n";

    // Editing titles
    cout << "Current Title: " << it->title << "\n";
    cout << "Enter new title (or press Enter to skip): ";
    string newTitle;
    getline(cin, newTitle);
    if (!newTitle.empty()) it->title = newTitle;

    // Edited by
    cout << "Current Author: " << it->author << "\n";
    cout << "Enter new author (or press Enter to skip): ";
    string newAuthor;
    getline(cin, newAuthor);
    if (!newAuthor.empty()) it->author = newAuthor;

    // Edit category
    cout << "Current Category: " << it->category << "\n";
    cout << "Enter new category (or press Enter to skip): ";
    string newCategory;
    getline(cin, newCategory);
    if (!newCategory.empty()) it->category = newCategory;

  
    cout << "Current Availability: " << (it->availability ? "Yes" : "No") << "\n";
    cout << "Change availability? (y/n or press Enter to skip): ";
    string avail;
    getline(cin, avail);
    if (!avail.empty()) {
        if (avail[0] == 'y' || avail[0] == 'Y' ||
            avail[0] == 'n' || avail[0] == 'N') {
            it->availability = (avail[0] == 'y' || avail[0] == 'Y');
        }
        else {
            cout << "Invalid input for availability. Skipping change.\n";
        }
    }


    sort(books.begin(), books.end(), [](const Book& a, const Book& b) {
        return a.ID < b.ID;
        });

    cout << "Book information updated.\n\n";
    if (!saveBooksToFile(books, "books.txt")) {
        cerr << "Error: Failed to save books to file after editing a book.\n";
    }
}

void deleteBook(vector<Book>& books) {
    if (books.empty()) {
        cout << "No books available to delete.\n\n";
        return;
    }

    cout << "Enter the book ID to delete: ";
    int targetID;
    validateIntegerInput(targetID);

    auto it = find_if(books.begin(), books.end(), [targetID](const Book& bk) {
        return bk.ID == targetID;
        });

    if (it == books.end()) {
        cout << "Book not found.\n\n";
        return;
    }

    if (!it->availability) {
        cout << "Cannot delete the book as it is currently borrowed.\n\n";
        return;
    }

    books.erase(it);
    cout << "Book deleted successfully.\n\n";
    if (!saveBooksToFile(books, "books.txt")) {
        cerr << "Error: Failed to save books to file after deleting a book.\n";
    }
}

void viewAllBooks(const vector<Book>& books) {
    if (books.empty()) {
        cout << "No books in the system.\n\n";
        return;
    }
    cout << "List of all books:\n";
    for (const auto& bk : books) {
        cout << "ID: " << bk.ID
            << ", Title: " << bk.title
            << ", Author: " << bk.author
            << ", Category: " << bk.category
            << ", Available: " << (bk.availability ? "Yes" : "No") << "\n";
    }
    cout << "\n";
}

// =================== Sorting Functions (for Admin) ===================

void sortBooksByTitle(vector<Book>& books) {
    bubbleSortBooksByTitle(books);  // �� utils.cpp ��ʵ��
    cout << "Books sorted by Title using Bubble Sort.\n\n";
}

void sortBooksByID(vector<Book>& books) {
    if (!books.empty()) {
        mergeSortBooksByID(books, 0, books.size() - 1);
        cout << "Books sorted by ID using Merge Sort.\n\n";
    }
}

void sortBooksByIDQuickSort(vector<Book>& books) {
    if (!books.empty()) {
        quickSortBooksByID(books, 0, books.size() - 1);
        cout << "Books sorted by ID using Quick Sort.\n\n";
    }
}

// =================== Transaction Management (Admin) ===================

void searchTransactionReceiptsByUserID_BinarySearch(vector<TransactionReceipt>& receipts) {
    if (receipts.empty()) {
        cout << "No transaction receipts available.\n\n";
        return;
    }

    cout << "Enter the User ID to search: ";
    string targetUserID;
    cin >> targetUserID;
    clearInputBuffer();

    // Ensure receipts are sorted by userID
    sort(receipts.begin(), receipts.end(), compareReceiptsByUserID);

    int index = binarySearchReceiptsByUserID(receipts, targetUserID);
    if (index != -1) {
        cout << "Transaction Receipt Found:\n";
        cout << "Receipt Number: " << receipts[index].receiptNumber
            << ", User ID: " << receipts[index].userID << "\n";
        cout << "Borrowed Book IDs: ";
        for (const auto& bookID : receipts[index].borrowedBookIDs) {
            cout << bookID << " ";
        }
        cout << "\nReturned: " << (receipts[index].returned ? "Yes" : "No") << "\n\n";
    }
    else {
        cout << "No transaction receipt found for User ID: " << targetUserID << ".\n\n";
    }
}


void selectionSortReceiptsAndView(const vector<TransactionReceipt>& receipts) {
    vector<TransactionReceipt> sortedReceipts = receipts; // Create a copy to sort
    selectionSortReceipts(sortedReceipts);
    if (sortedReceipts.empty()) {
        cout << "No transaction receipts available.\n\n";
        return;
    }
    cout << "Transaction Receipts (Sorted by Receipt Number):\n";
    for (const auto& rc : sortedReceipts) {
        cout << "Receipt #: " << rc.receiptNumber
            << ", User ID: " << rc.userID << "\n";
        cout << "Borrowed Book IDs: ";
        for (const auto& bookID : rc.borrowedBookIDs) {
            cout << bookID << " ";
        }
        cout << "\nReturned: " << (rc.returned ? "Yes" : "No") << "\n\n";
    }
    cout << "\n";
}


void viewTransactionReceipts(const vector<TransactionReceipt>& receipts) {
    if (receipts.empty()) {
        cout << "No transaction receipts available.\n\n";
        return;
    }
    cout << "Transaction Receipts:\n";
    for (const auto& rc : receipts) {
        cout << "Receipt #: " << rc.receiptNumber
            << ", User ID: " << rc.userID << "\n";
        cout << "Borrowed Book IDs: ";
        for (const auto& bookID : rc.borrowedBookIDs) {
            cout << bookID << " ";
        }
        cout << "\nReturned: " << (rc.returned ? "Yes" : "No") << "\n\n";

    }
    cout << "\n";
}
