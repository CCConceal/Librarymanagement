#include "book.h"

Book::Book()
    : ID(0), title(""), author(""), category(""), availability(true) {}

Book::Book(int id, const std::string& t, const std::string& a,
    const std::string& c, bool avail)
    : ID(id), title(t), author(a), category(c), availability(avail) {}
