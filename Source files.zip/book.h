#ifndef BOOK_H
#define BOOK_H

#include <string>

struct Book {
    int ID;
    std::string title;
    std::string author;
    std::string category;
    bool availability;

    // Default constructor
    Book();
    // Parameterized constructor
    Book(int id, const std::string& title, const std::string& author = "",
        const std::string& category = "", bool avail = true);
};

#endif // BOOK_H

