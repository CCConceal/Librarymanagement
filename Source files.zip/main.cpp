#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <stdexcept>
#include "admin.h"
#include "user.h"
#include "utils.h"
#include<algorithm>

using namespace std;

void displayControlPanel(vector<Book>& books,
    vector<TransactionReceipt>& receipts,
    vector<User>& users,
    int& nextBookID,
    int& nextReceiptNumber);


bool login(const string& role, string& loggedInUserID, const vector<User>& users) {
    const int MAX_ATTEMPTS = 3;
    int attempts = 0;
    string username, password, userID;

    while (attempts < MAX_ATTEMPTS) {
        cout << "Enter username: ";
        cin >> username;
        cout << "Enter password: ";
        cin >> password;

        if (role == "user") {
            while (true) {
                cout << "Enter User ID (format Uxxx, e.g., U001): ";
                cin >> userID;
                if (validateUserIDFormat(userID)) {
                    break;
                }
                else {
                    cout << "Invalid User ID format. Please try again.\n";
                }
            }
        }

        if (role == "admin") {
            if (username == "admin" && password == "123456") {
                cout << "Successfully logged in as admin!\n\n";
                loggedInUserID = "admin";
                return true;
            }
        }
        else if (role == "user") {
            auto it = find_if(users.begin(), users.end(), [&](const User& u) {
                return u.username == username && u.password == password && u.userID == userID;
                });
            if (it != users.end()) {
                cout << "Successfully logged in as " << it->username << "!\n";
                cout << "Your User ID: " << it->userID << "\n\n";
                loggedInUserID = it->userID;
                return true;
            }
        }

        attempts++;
        cout << "Invalid credentials. Please try again. (" << attempts << "/" << MAX_ATTEMPTS << ")\n\n";
    }

    cout << "Maximum login attempts exceeded. Exiting...\n";
    exit(0);
    return false;
}

// =================== ������ ===================

int main() {
    srand(static_cast<unsigned int>(time(0))); // Initialize random seed

    vector<Book> books;
    vector<TransactionReceipt> receipts;
    vector<User> users;
    int nextBookID = 1;
    int nextReceiptNumber = 1;

    try {
        // Load users from file
        if (!loadUsersFromFile(users, "users.txt")) {
            cerr << "Error: Failed to load users from \"users.txt\".\n";
            logError("Failed to load users from \"users.txt\".");
            throw runtime_error("Users file loading failed.");
        }

        // Load books from file
        if (!loadBooksFromFile(books, "books.txt", nextBookID)) {
            cerr << "Error: Failed to load books from \"books.txt\".\n";
            logError("Failed to load books from \"books.txt\".");
            throw runtime_error("Books file loading failed.");
        }

        // Load receipts from file
        if (!loadReceiptsFromFile(receipts, "receipts.txt", nextReceiptNumber)) {
            cout << "No receipts found. Starting with no transaction receipts.\n\n";
        }

        // Display control panel
        displayControlPanel(books, receipts, users, nextBookID, nextReceiptNumber);

        // Save data before exiting
        if (!saveBooksToFile(books, "books.txt")) {
            throw runtime_error("Failed to save books to file.");
        }
        if (!saveReceiptsToFile(receipts, "receipts.txt")) {
            throw runtime_error("Failed to save receipts to file.");
        }
     

        cout << "Program terminated.\n";
    }
    catch (const exception& e) {
        cerr << "Critical error occurred: " << e.what() << "\n";
        logError(string("Critical error: ") + e.what());
        return 1;
    }

    return 0;
}

// =================== display the main control panel ===================

void displayControlPanel(vector<Book>& books,
    vector<TransactionReceipt>& receipts,
    vector<User>& users,
    int& nextBookID,
    int& nextReceiptNumber) {
    int choice;
    do {
        cout << "===== Main Control Panel =====\n"
            << "1. Login as Admin\n"
            << "2. Login as User\n"
            << "3. Exit\n"
            << "Please select an option: ";

        if (!(cin >> choice)) {
            cout << "Invalid input. Please enter a number between 1 and 3.\n\n";
            clearInputBuffer();
            continue;
        }
        clearInputBuffer();

        string loggedInUserID; // To store logged-in user ID

        switch (choice) {
        case 1:
            cout << "\nAdmin Login\n";
            if (login("admin", loggedInUserID, users)) {
                cout << "Welcome to the Admin Panel!\n\n";
                displayAdminControlPanel(books, receipts, users, nextBookID, nextReceiptNumber);
            }
            break;
        case 2:
            cout << "\nUser Login\n";
            if (login("user", loggedInUserID, users)) {
                cout << "Welcome to the User Panel!\n\n";
                displayUserControlPanel(books, receipts, loggedInUserID, nextReceiptNumber);
            }
            break;
        case 3:
            cout << "Exiting the system. Goodbye!\n";
            return;
        default:
            cout << "Invalid option. Please select a number between 1 and 3.\n\n";
            break;
        }
    } while (choice != 3);
}
