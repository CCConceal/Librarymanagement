#include <iostream>
#include <algorithm>
#include <ctime>
#include <sstream>
#include <stdexcept>
#include <vector>
#include <limits>

// Include relevant headers
#include "user.h"
#include "book.h"
#include "transaction.h"
#include "utils.h"

using namespace std;

// =================== User Constructors ===================

User::User() : username(""), password(""), userID("") {}

User::User(const std::string& uname, const std::string& pwd, const std::string& uid)
    : username(uname), password(pwd), userID(uid) {}

// =================== User Panel ===================

void displayUserControlPanel(vector<Book>& books,
    vector<TransactionReceipt>& receipts,
    const string& userID,
    int& nextReceiptNumber) {
    int choice;
    do {
        std::cout << "===== User Control Panel =====\n"
            << "1. Search Books by Title\n"
            << "2. Borrow a Book\n"
            << "3. View My Borrowing Records\n"
            << "4. Return a Book\n"
            << "5. Return to Main Control Panel\n"
            << "Please select an option: ";

        if (!(cin >> choice)) {
            std::cout << "Invalid input. Please enter a number between 1 and 5.\n\n";
            clearInputBuffer();
            continue;
        }
        clearInputBuffer();

        switch (choice) {
        case 1:
            searchBookByTitle(books);
            break;
        case 2:
            borrowBook(books, receipts, userID, nextReceiptNumber);
            break;
        case 3:
            viewTransactionHistoryByUserID(receipts, userID);
            break;
        case 4:
            returnBook(books, receipts, userID);
            break;
        case 5:
            std::cout << "Returning to Main Control Panel...\n\n";
            return;
        default:
            std::cout << "Invalid option. Please try again.\n\n";
            break;
        }
    } while (choice != 5);
}

// =================== Borrow and Return Books ===================

void borrowBook(vector<Book>& books,
    vector<TransactionReceipt>& receipts,
    const string& userID,
    int& nextReceiptNumber) {

    vector<int> borrowedBookIDs; // Temporary storage of borrowed book IDs

    bool continueBorrowing = true;

    while (continueBorrowing) {
        std::cout << "\nAvailable Books:\n";
        displayBooks(books);

        std::cout << "\nEnter the book ID you want to borrow: ";
        int bookID;
        if (!validateIntegerInput(bookID, 1, 1000000)) { // Assuming that the maximum value of the book ID is 1000000
            std::cout << "Invalid input for Book ID.\n\n";
            continue;
        }

        int index = binarySearchBookByID(books, bookID);
        if (index == -1) {
            std::cout << "Book with the given ID not found.\n\n";
            continue;
        }

        if (!books[index].availability) {
            std::cout << "The book \"" << books[index].title << "\" is currently not available for borrowing.\n\n";
            continue;
        }

        books[index].availability = false;
        borrowedBookIDs.push_back(bookID);

        std::cout << "Book \"" << books[index].title << "\" borrowed successfully!\n\n";

        char moreBooks;
        bool validInput = false;

        while (!validInput) {
            std::cout << "Would you like to borrow another book? (y/n): ";
            cin >> moreBooks;
            clearInputBuffer();

            if (moreBooks == 'y' || moreBooks == 'Y') {
                validInput = true; // continue borrowing
            }
            else if (moreBooks == 'n' || moreBooks == 'N') {
                validInput = true;
                continueBorrowing = false; // stop borrowing
            }
            else {
                std::cout << "Invalid input. Please enter 'y' or 'n'.\n";
            }
        }
    }

    if (borrowedBookIDs.empty()) {
        std::cout << "No books were borrowed.\n\n";
        return;
    }

    // Quick sorting of borrowed book IDs
    quickSortBookIDs(borrowedBookIDs, 0, static_cast<int>(borrowedBookIDs.size()) - 1);

    // Create summary receipts
    TransactionReceipt newReceipt(nextReceiptNumber++, userID, borrowedBookIDs, false);
    receipts.push_back(newReceipt);

    // Save changes to file
    if (!saveBooksToFile(books, "books.txt")) {
        cerr << "Error: Failed to save books to file after borrowing books.\n";
    }
    if (!saveReceiptsToFile(receipts, "receipts.txt")) {
        cerr << "Error: Failed to save receipts to file after borrowing books.\n";
    }

    // Print summary receipts
    std::cout << "\n--- Transaction Receipt ---\n";
    std::cout << "Receipt Number: " << newReceipt.receiptNumber << "\n";
    std::cout << "User ID: " << newReceipt.userID << "\n";
    std::cout << "Borrowed Books:\n";
    for (const auto& id : newReceipt.borrowedBookIDs) {
        auto bookIt = find_if(books.begin(), books.end(), [&](const Book& b) {
            return b.ID == id;
            });
        if (bookIt != books.end()) {
            std::cout << " - ID: " << bookIt->ID << ", Title: " << bookIt->title << "\n";
        }
    }
    // Calculation of return date (after 7 days)
    time_t t = time(0) + (7 * 24 * 60 * 60);
    struct tm dueDate;
#ifdef _WIN32
    localtime_s(&dueDate, &t);
#else
    if (localtime_r(&t, &dueDate) == nullptr) {
        cerr << "Failed to calculate due date.\n";
    }
#endif
    std::cout << "Return Due Date: "
        << (1900 + dueDate.tm_year) << "-"
        << (1 + dueDate.tm_mon) << "-"
        << dueDate.tm_mday << "\n";
    std::cout << "---------------------------\n\n";
}



void returnBook(vector<Book>& books,
    vector<TransactionReceipt>& receipts,
    const string& userID) {

    // Collection of all unreturned books and their corresponding receipts and indexes
    struct ReturnInfo {
        TransactionReceipt* receipt;
        size_t bookIndex; 
        int bookID;
    };

    vector<ReturnInfo> userBorrowedBooks;

    for (auto& receipt : receipts) {
        if (receipt.userID == userID && !receipt.returned) {
            for (size_t i = 0; i < receipt.borrowedBookIDs.size(); ++i) {
                userBorrowedBooks.push_back(ReturnInfo{ &receipt, i, receipt.borrowedBookIDs[i] });
            }
        }
    }

    if (userBorrowedBooks.empty()) {
        std::cout << "You have no borrowed books to return.\n\n";
        return;
    }

    // Used to store information about books returned by the user
    struct ReturnedBook {
        int bookID;
        std::string title;
    };
    vector<ReturnedBook> returnedBooks;

    bool continueReturning = true;

    while (continueReturning && !userBorrowedBooks.empty()) {
        // Show all returnable books
        std::cout << "\nYour Borrowed Books:\n";
        for (size_t i = 0; i < userBorrowedBooks.size(); ++i) {
            int bookID = userBorrowedBooks[i].bookID;
            auto bookIt = std::find_if(books.begin(), books.end(), [&](const Book& b) {
                return b.ID == bookID;
                });
            if (bookIt != books.end()) {
                std::cout << i + 1 << ". " << bookIt->title << " (ID: " << bookIt->ID << ")\n";
            }
        }

        // User selects books to be returned
        std::cout << "Enter the number of the book you want to return (or 0 to cancel): ";
        int choice;
        if (!(cin >> choice)) {
            std::cout << "Invalid input. Returning to User Control Panel.\n\n";
            clearInputBuffer();
            return;
        }
        clearInputBuffer();

        if (choice == 0) {
            std::cout << "Return book operation cancelled.\n\n";
            break;
        }

        if (choice < 1 || choice > static_cast<int>(userBorrowedBooks.size())) {
            std::cout << "Invalid choice. Please try again.\n\n";
            continue;
        }

        // Get information about books to be returned
        ReturnInfo selectedReturn = userBorrowedBooks[choice - 1];
        int bookID = selectedReturn.bookID;

        // Updating the availability of books
        auto bookIt = std::find_if(books.begin(), books.end(), [&](const Book& b) {
            return b.ID == bookID;
            });

        if (bookIt != books.end()) {
            bookIt->availability = true;
        }
        else {
            cerr << "Error: Book ID " << bookID << " not found in books list.\n";
            continue;
        }


        selectedReturn.receipt->borrowedBookIDs.erase(selectedReturn.receipt->borrowedBookIDs.begin() + selectedReturn.bookIndex);


        if (selectedReturn.receipt->borrowedBookIDs.empty()) {
            selectedReturn.receipt->returned = true;
        }

        // Add returned book information to the returnedBooks list.
        ReturnedBook rb;
        rb.bookID = bookID;
        rb.title = bookIt->title;
        returnedBooks.push_back(rb);

        // Removing Returned Books from userBorrowedBooks
        userBorrowedBooks.erase(userBorrowedBooks.begin() + (choice - 1));


        if (userBorrowedBooks.empty()) {
            std::cout << "All your borrowed books have been returned.\n\n";
            break;
        }

        //  Input validation loop
        char moreBooks;
        bool validInput = false;

        while (!validInput) {
            std::cout << "Would you like to return another book? (y/n): ";
            cin >> moreBooks;
            clearInputBuffer();

            if (moreBooks == 'y' || moreBooks == 'Y') {
                validInput = true; 
            }
            else if (moreBooks == 'n' || moreBooks == 'N') {
                validInput = true;
                continueReturning = false; // stop returning
            }
            else {
                std::cout << "Invalid input. Please enter 'y' or 'n'.\n";
            }
        }
    }

    if (returnedBooks.empty()) {
        std::cout << "No books were returned.\n\n";
        return;
    }

    // Save changes to file
    try {
        if (!saveBooksToFile(books, "books.txt")) {
            throw runtime_error("Failed to save books to file.");
        }
        if (!saveReceiptsToFile(receipts, "receipts.txt")) {
            throw runtime_error("Failed to save receipts to file.");
        }
    }
    catch (const exception& e) {
        // Rollback Changes
        for (const auto& returnInfo : returnedBooks) {
            // Restoring the availability of books
            auto bookIt = std::find_if(books.begin(), books.end(), [&](const Book& b) {
                return b.ID == returnInfo.bookID;
                });
            if (bookIt != books.end()) {
                bookIt->availability = false;
            }

            
            for (auto& receipt : receipts) {
                if (receipt.userID == userID && !receipt.returned) {
                    receipt.borrowedBookIDs.push_back(returnInfo.bookID);
                    break;
                }
            }
        }
        cerr << "Transaction failed: " << e.what() << "\nRolling back changes.\n\n";
        return;
    }

    // Generate book return receipts
    std::cout << "\n--- Return Receipt ---\n";
    std::cout << "User ID: " << userID << "\n";
    std::cout << "Books Returned:\n";
    for (const auto& rb : returnedBooks) {
        std::cout << " - ID: " << rb.bookID << ", Title: " << rb.title << "\n";
    }
    // calculate the return date
    time_t t = time(0);
    struct tm returnDate;
#ifdef _WIN32
    localtime_s(&returnDate, &t);
#else
    if (localtime_r(&t, &returnDate) == nullptr) {
        cerr << "Failed to get current date.\n";
    }
#endif
    std::cout << "Return Date: "
        << (1900 + returnDate.tm_year) << "-"
        << (1 + returnDate.tm_mon) << "-"
        << returnDate.tm_mday << "\n";
    std::cout << "-----------------------\n\n";
}



// =================== View Transaction History (User) ===================

void viewTransactionHistoryByUserID(const vector<TransactionReceipt>& receipts,
    const string& userID) {
    if (receipts.empty()) {
        std::cout << "No borrowing records available.\n\n";
        return;
    }
    bool found = false;
    std::cout << "\nBorrowing records for " << userID << ":\n";

    for (const auto& receipt : receipts) {
        if (receipt.userID == userID) {
            found = true;
            std::cout << "Receipt #: " << receipt.receiptNumber << "\n";
            std::cout << "Borrowed Book IDs: ";
            for (const auto& bookID : receipt.borrowedBookIDs) {
                std::cout << bookID << " ";
            }
            std::cout << "\nReturned: " << (receipt.returned ? "Yes" : "No") << "\n\n";
        }
    }
    if (!found) {
        std::cout << "No borrowing records found for user " << userID << ".\n";
    }
    std::cout << "\n";
}
