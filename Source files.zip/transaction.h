#ifndef TRANSACTION_H
#define TRANSACTION_H
#include<vector>
#include <string>

struct TransactionReceipt {
    int receiptNumber;
    std::string userID;
    std::vector<int> borrowedBookIDs; 
    bool returned; 

    TransactionReceipt(int receipt, const std::string& user, const std::vector<int>& bookIDs, bool ret = false);
};




#endif // TRANSACTION_H

