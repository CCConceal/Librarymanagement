#ifndef ADMIN_H
#define ADMIN_H

#include <vector>
#include "book.h"
#include "transaction.h"
#include "user.h"


void displayAdminControlPanel(std::vector<Book>& books,
    std::vector<TransactionReceipt>& receipts,
    const std::vector<User>& users,
    int& nextBookID,
    int& nextReceiptNumber);


void addBook(std::vector<Book>& books, int& nextBookID);
void searchBookByID(const std::vector<Book>& books);
void editBook(std::vector<Book>& books);
void deleteBook(std::vector<Book>& books);
void viewAllBooks(const std::vector<Book>& books);
void sortBooksByTitle(std::vector<Book>& books);
void sortBooksByID(std::vector<Book>& books);
void sortBooksByIDQuickSort(std::vector<Book>& books);
void searchTransactionReceiptsByUserID_BinarySearch(std::vector<TransactionReceipt>& receipts);
void selectionSortReceiptsAndView(const std::vector<TransactionReceipt>& receipts);
void viewTransactionReceipts(const std::vector<TransactionReceipt>& receipts);

#endif // ADMIN_H
