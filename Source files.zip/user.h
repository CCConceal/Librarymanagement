#ifndef USER_H
#define USER_H

#include <string>
#include <vector>
#include "transaction.h"
#include "book.h"


struct User {
    std::string username;
    std::string password;
    std::string userID;

    User();
    User(const std::string& uname, const std::string& pwd, const std::string& uid);
};


void displayUserControlPanel(std::vector<Book>& books,
    std::vector<TransactionReceipt>& receipts,
    const std::string& userID,
    int& nextReceiptNumber);


void borrowBook(std::vector<Book>& books,
    std::vector<TransactionReceipt>& receipts,
    const std::string& userID, int& nextReceiptNumber);

void returnBook(std::vector<Book>& books,
    std::vector<TransactionReceipt>& receipts,
    const std::string& userID);

void searchBookByTitle(std::vector<Book>& books);
void viewTransactionHistoryByUserID(const std::vector<TransactionReceipt>& receipts,
    const std::string& userID);

#endif // USER_H

