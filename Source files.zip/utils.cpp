#include "utils.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <stdexcept>
#include<vector>
#include <ctime>
#include <random>
using namespace std;

// =================== implementation ===================

void clearInputBuffer() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

bool validateIntegerInput(int& input, int min, int max) {
    while (true) {
        if (cin >> input) {
            if (input >= min && input <= max) {
                clearInputBuffer();
                return true;
            }
            else {
                std::cout << "Input out of valid range (" << min << " to " << max << "). Please try again: ";
            }
        }
        else {
            std::cout << "Invalid input. Please enter a valid integer: ";
            clearInputBuffer();
        }
    }
}

bool validateUserIDFormat(const std::string& userID) {
    if (userID.size() != 4) return false;
    if (userID[0] != 'U') return false;
    for (int i = 1; i < 4; ++i) {
        if (!isdigit(userID[i])) return false;
    }
    return true;
}

void logError(const std::string& errorMessage) {
    std::ofstream logFile("error.log", std::ios::app);
    if (logFile.is_open()) {
        // Get current time
        time_t now = time(0);
        struct tm tstruct;
        char buf[80];
#ifdef _WIN32
        localtime_s(&tstruct, &now);
#else
        localtime_r(&now, &tstruct);
#endif
        strftime(buf, sizeof(buf), "%Y-%m-%d.%X", &tstruct);
        logFile << "[" << buf << "] " << errorMessage << "\n";
        logFile.close();
    }
}


void shuffleBooks(std::vector<Book>& books) {
    // Initialize a random number generator with a random seed
    std::random_device rd;
    std::mt19937 g(rd());

    // Shuffle the books vector
    std::shuffle(books.begin(), books.end(), g);

    std::cout << "Books have been shuffled successfully!\n\n";
}

// =================== file operation ===================

bool saveBooksToFile(const vector<Book>& books, const string& filename) {
    int retryCount = 3;
    while (retryCount > 0) {
        ofstream outFile(filename);
        if (!outFile) {
            string errorMsg = "Error: Unable to open file \"" + filename + "\" for writing.";
            cerr << errorMsg << "\n";
            logError(errorMsg);
            retryCount--;
            if (retryCount > 0) {
                std::cout << "Please check the file path and permissions. Retrying... ("
                    << retryCount << " attempts left)\n";
                continue;
            }
            else {
                string finalError = "Failed to save books after multiple attempts.";
                cerr << finalError << "\n";
                logError(finalError);
                return false;
            }
        }

        for (const auto& book : books) {
            outFile << book.ID << "|"
                << book.title << "|"
                << book.author << "|"
                << book.category << "|"
                << (book.availability ? "1" : "0") << "\n";
            if (!outFile) {
                string errorMsg = "Error: Failed to write to file \"" + filename + "\".";
                cerr << errorMsg << "\n";
                logError(errorMsg);
                outFile.close();
                retryCount--;
                if (retryCount > 0) {
                    std::cout << "Retrying... (" << retryCount << " attempts left)\n";
                    continue;
                }
                else {
                    string finalError = "Failed to save books after multiple attempts.";
                    cerr << finalError << "\n";
                    logError(finalError);
                    return false;
                }
            }
        }

        outFile.close();
        return true;
    }
    return false;
}

bool loadBooksFromFile(std::vector<Book>& books, const std::string& filename, int& nextBookID) {
    std::ifstream inFile(filename);
    if (!inFile.is_open()) {
        logError("Failed to open books file: " + filename);
        return false;
    }

    std::string line;
    while (std::getline(inFile, line)) {
        if (line.empty()) continue; // Skip empty lines

        std::stringstream ss(line);
        std::string idStr, title, author, category, availStr;

        if (!std::getline(ss, idStr, '|') ||
            !std::getline(ss, title, '|') ||
            !std::getline(ss, author, '|') ||
            !std::getline(ss, category, '|') ||
            !std::getline(ss, availStr, '|')) {
            logError("Invalid book entry: " + line);
            continue; // Skip invalid entries
        }

        try {
            int id = std::stoi(idStr);
            bool availability = (availStr == "1");
            books.emplace_back(id, title, author, category, availability);

            if (id >= nextBookID) {
                nextBookID = id + 1;
            }

            // Debug output
            std::cout << "Loaded book: ID=" << id << ", Title=" << title << "\n";
        }
        catch (const std::invalid_argument& e) {
            logError("Invalid book ID in line: " + line + " | Error: " + e.what());
            continue; // Skip invalid entries
        }
        catch (const std::out_of_range& e) {
            logError("Book ID out of range in line: " + line + " | Error: " + e.what());
            continue; // Skip invalid entries
        }
    }

    inFile.close();
    return true;
}





bool saveReceiptsToFile(const vector<TransactionReceipt>& receipts, const string& filename) {
    ofstream outFile(filename);
    if (!outFile) {
        cerr << "Error: Unable to open file \"" << filename << "\" for writing.\n";
        return false;
    }

    for (const auto& receipt : receipts) {
        outFile << receipt.receiptNumber << "|"
            << receipt.userID << "|";
        
        for (size_t i = 0; i < receipt.borrowedBookIDs.size(); ++i) {
            outFile << receipt.borrowedBookIDs[i];
            if (i != receipt.borrowedBookIDs.size() - 1) {
                outFile << ",";
            }
        }
        outFile << "|" << (receipt.returned ? "1" : "0") << "\n";
        if (!outFile) {
            cerr << "Error: Failed to write to file \"" << filename << "\".\n";
            outFile.close();
            return false;
        }
    }

    outFile.close();
    return true;
}

bool loadReceiptsFromFile(std::vector<TransactionReceipt>& receipts, const std::string& filename, int& nextReceiptNumber) {
    std::ifstream inFile(filename);
    if (!inFile.is_open()) {
        logError("Failed to open receipts file: " + filename);
        return false;
    }

    std::string line;
    while (std::getline(inFile, line)) {
        if (line.empty()) continue; // Skip empty lines

        std::stringstream ss(line);
        std::string receiptNumStr, userID, borrowedIDsStr, returnedStr;

        if (!std::getline(ss, receiptNumStr, '|') ||
            !std::getline(ss, userID, '|') ||
            !std::getline(ss, borrowedIDsStr, '|') ||
            !std::getline(ss, returnedStr, '|')) {
            logError("Invalid receipt entry: " + line);
            continue; // Skip invalid entries
        }

        try {
            int receiptNum = std::stoi(receiptNumStr);
            bool returned = (returnedStr == "1");
            std::vector<int> borrowedIDs;

            if (!borrowedIDsStr.empty()) {
                std::stringstream idsStream(borrowedIDsStr);
                std::string idStr;
                while (std::getline(idsStream, idStr, ',')) {
                    if (!idStr.empty()) { // Ensure idStr is not empty
                        borrowedIDs.push_back(std::stoi(idStr));
                    }
                }
            }

            receipts.emplace_back(receiptNum, userID, borrowedIDs, returned);

            if (receiptNum >= nextReceiptNumber) {
                nextReceiptNumber = receiptNum + 1;
            }

            // Debug output
            std::cout << "Loaded receipt: Number=" << receiptNum << ", UserID=" << userID << "\n";
        }
        catch (const std::invalid_argument& e) {
            logError("Invalid receipt number in line: " + line + " | Error: " + e.what());
            continue; // Skip invalid entries
        }
        catch (const std::out_of_range& e) {
            logError("Receipt number out of range in line: " + line + " | Error: " + e.what());
            continue; // Skip invalid entries
        }
    }

    inFile.close();
    return true;
}



bool loadUsersFromFile(vector<User>& users, const string& filename) {
    ifstream inFile(filename);
    if (!inFile) {
        cerr << "Warning: File \"" << filename << "\" not found. Starting with no users.\n";
        return false;
    }

    string line;
    while (getline(inFile, line)) {
        if (line.empty()) continue;
        size_t pos1 = line.find("|");
        if (pos1 == string::npos) continue;
        size_t pos2 = line.find("|", pos1 + 1);
        if (pos2 == string::npos) continue;

        string uname = line.substr(0, pos1);
        string pwd = line.substr(pos1 + 1, pos2 - pos1 - 1);
        string uid = line.substr(pos2 + 1);

        users.emplace_back(uname, pwd, uid);
    }

    inFile.close();
    return true;
}

bool saveUsersToFile(const vector<User>& users, const string& filename) {
    ofstream outFile(filename);
    if (!outFile) {
        cerr << "Error: Unable to open file \"" << filename << "\" for writing.\n";
        return false;
    }

    for (const auto& user : users) {
        outFile << user.username << "|" << user.password << "|" << user.userID << "\n";
        if (!outFile) {
            cerr << "Error: Failed to write to file \"" << filename << "\".\n";
            outFile.close();
            return false;
        }
    }

    outFile.close();
    return true;
}

// =================== finding and displaying ===================

int findNextAvailableBookID(const vector<Book>& books) {
    int id = 1;
    for (const auto& book : books) {
        if (book.ID == id) {
            id++;
        }
        else if (book.ID > id) {
            break;
        }
    }
    return id;
}

void displayBooks(const vector<Book>& books) {
    for (const auto& book : books) {
        if (book.availability) {
            std::cout << "ID: " << book.ID
                << ", Title: \"" << book.title
                << "\", Available: Yes\n";
        }
    }
    std::cout << "-----------------------------\n";
}

// =================== binary search ===================

int binarySearchBookByID(const vector<Book>& books, int targetID) {
    int left = 0;
    int right = static_cast<int>(books.size()) - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (books[mid].ID == targetID) {
            return mid;
        }
        else if (books[mid].ID < targetID) {
            left = mid + 1;
        }
        else {
            right = mid - 1;
        }
    }
    return -1; // Not found
}

bool compareReceiptsByUserID(const TransactionReceipt& a, const TransactionReceipt& b) {
    return a.userID < b.userID;
}

int binarySearchReceiptsByUserID(const vector<TransactionReceipt>& receipts,
    const string& targetUserID) {
    int left = 0;
    int right = static_cast<int>(receipts.size()) - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (receipts[mid].userID == targetUserID) {
            return mid;
        }
        else if (receipts[mid].userID < targetUserID) {
            left = mid + 1;
        }
        else {
            right = mid - 1;
        }
    }
    return -1; // Not found
}

// =================== sorting implementation (Books) ===================

void bubbleSortBooksByTitle(const vector<Book>& books) {
    vector<Book> sortedBooks = books;
    bool swapped;
    for (size_t i = 0; i < sortedBooks.size(); i++) {
        swapped = false;
        for (size_t j = 0; j < sortedBooks.size() - i - 1; j++) {
            if (sortedBooks[j].title > sortedBooks[j + 1].title) {
                std::swap(sortedBooks[j], sortedBooks[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;
    }

    std::cout << "List of Books Sorted by Title (Bubble Sort:\n";
    std::cout << "---------------------------------------\n";
    for (const auto& book : sortedBooks) {
        std::cout << "ID: " << book.ID
            << ", Title: \"" << book.title << "\""
            << ", Author: " << book.author
            << ", Category: " << book.category
            << ", Available: " << (book.availability ? "Yes" : "No") << "\n";
    }
    std::cout << "---------------------------------------\n\n";
}

void mergeByID(vector<Book>& books, int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    vector<Book> L(n1);
    vector<Book> R(n2);
    for (int i = 0; i < n1; i++) {
        L[i] = books[left + i];
    }
    for (int j = 0; j < n2; j++) {
        R[j] = books[mid + 1 + j];
    }

    int i = 0, j = 0;
    int k = left;
    while (i < n1 && j < n2) {
        if (L[i].ID <= R[j].ID) {
            books[k] = L[i];
            i++;
        }
        else {
            books[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        books[k] = L[i];
        i++;
        k++;
    }
    while (j < n2) {
        books[k] = R[j];
        j++;
        k++;
    }
}

void mergeSortBooksByID(vector<Book>& books, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSortBooksByID(books, left, mid);
        mergeSortBooksByID(books, mid + 1, right);
        mergeByID(books, left, mid, right);
    }
}

int partitionBooksByID(vector<Book>& books, int left, int right) {
    int pivotIndex = left + rand() % (right - left + 1);
    swap(books[left], books[pivotIndex]);
    int pivot = books[left].ID;
    int i = left + 1;
    for (int j = left + 1; j <= right; j++) {
        if (books[j].ID < pivot) {
            swap(books[i], books[j]);
            i++;
        }
    }
    swap(books[left], books[i - 1]);
    return i - 1;
}

void quickSortBooksByID(vector<Book>& books, int left, int right) {
    if (left < right) {
        int pivotPos = partitionBooksByID(books, left, right);
        quickSortBooksByID(books, left, pivotPos - 1);
        quickSortBooksByID(books, pivotPos + 1, right);
    }
}



void searchBookByTitle(vector<Book>& books) {
    if (books.empty()) {
        cout << "No books in the system.\n\n";
        return;
    }

    cout << "Enter part of the book title to search: ";
    string targetTitle;
    getline(cin, targetTitle);

    bool found = false;
    for (const auto& book : books) {
        if (book.title.find(targetTitle) != string::npos) {
            cout << "Book found:\n";
            cout << "ID: " << book.ID
                << "\nTitle: " << book.title
                << "\nAuthor: " << book.author
                << "\nCategory: " << book.category
                << "\nAvailable: " << (book.availability ? "Yes" : "No") << "\n\n";
            found = true;
        }
    }

    if (!found) {
        cout << "No matching books found.\n\n";
    }
}

// =================== selection sort (Receipts) ===================

void selectionSortReceipts(std::vector<TransactionReceipt>& receipts) {
    size_t n = receipts.size();
    for (size_t i = 0; i < n - 1; ++i) {
        size_t min_idx = i;
        for (size_t j = i + 1; j < n; ++j) {
            if (receipts[j].receiptNumber < receipts[min_idx].receiptNumber) {
                min_idx = j;
            }
        }
        std::swap(receipts[i], receipts[min_idx]);
    }
}


// quicsort for receips
void quickSortBookIDs(vector<int>& bookIDs, int left, int right) {
    if (left < right) {
        int pivot = bookIDs[right];
        int i = left - 1;
        for (int j = left; j < right; j++) {
            if (bookIDs[j] < pivot) {
                i++;
                swap(bookIDs[i], bookIDs[j]);
            }
        }
        swap(bookIDs[i + 1], bookIDs[right]);
        int pi = i + 1;

        quickSortBookIDs(bookIDs, left, pi - 1);
        quickSortBookIDs(bookIDs, pi + 1, right);
    }
}


