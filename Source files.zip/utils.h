#ifndef UTILS_H
#define UTILS_H

#include <vector>
#include <string>
#include "book.h"
#include "transaction.h"
#include "user.h"

// =================== declaration ===================
void clearInputBuffer();
bool validateIntegerInput(int& input, int min = INT32_MIN, int max = INT32_MAX);
bool validateUserIDFormat(const std::string& userID);
void logError(const std::string& errorMessage);

// =================== file operations ===================
bool saveBooksToFile(const std::vector<Book>& books, const std::string& filename);
bool loadBooksFromFile(std::vector<Book>& books, const std::string& filename, int& nextBookID);

bool saveReceiptsToFile(const std::vector<TransactionReceipt>& receipts, const std::string& filename);
bool loadReceiptsFromFile(std::vector<TransactionReceipt>& receipts, const std::string& filename, int& nextReceiptNumber);


bool loadUsersFromFile(std::vector<User>& users, const std::string& filename);
bool saveUsersToFile(const std::vector<User>& users, const std::string& filename);

// =================== finding and displaying ===================
int findNextAvailableBookID(const std::vector<Book>& books);
void displayBooks(const std::vector<Book>& books);

// =================== binary search ===================
int binarySearchBookByID(const std::vector<Book>& books, int targetID);

// =================== sorting and searching��Receipts�� ===================
bool compareReceiptsByUserID(const TransactionReceipt& a, const TransactionReceipt& b);
int binarySearchReceiptsByUserID(const std::vector<TransactionReceipt>& receipts, const std::string& targetUserID);

// =================== sorting algorithms��Books�� ===================
void bubbleSortBooksByTitle(const std::vector<Book>& books);
void mergeSortBooksByID(std::vector<Book>& books, int left, int right);
void quickSortBooksByID(std::vector<Book>& books, int left, int right);

void mergeByID(std::vector<Book>& books, int left, int mid, int right);
int partitionBooksByID(std::vector<Book>& books, int left, int right);

// =================== slection sort(Receipts) ===================
void selectionSortReceipts(std::vector<TransactionReceipt>& receipts);
void quickSortBookIDs(std::vector<int>& bookIDs, int left, int right);

void shuffleBooks(std::vector<Book>& books);

#endif // UTILS_H

