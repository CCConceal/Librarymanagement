#include "transaction.h"
#include <vector> 

TransactionReceipt::TransactionReceipt(int receipt, const std::string& user,
    const std::vector<int>& bookIDs, bool ret)
    : receiptNumber(receipt), userID(user), borrowedBookIDs(bookIDs), returned(ret) {}
